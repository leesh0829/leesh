import CalendarClient from "./CalenderClient";

export const runtime = "nodejs";

export default function CalendarPage() {
  return <CalendarClient />;
}
